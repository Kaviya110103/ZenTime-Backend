package com.example.demo.service;

import com.example.demo.MODELS.AttendanceRecord;
import com.example.demo.MODELS.Employee;
import com.example.demo.repo.AttendanceRecordRepository;
import com.example.demo.repo.EmployeeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AttendanceService {

    @Autowired
    private AttendanceRecordRepository attendanceRepo;

    @Autowired
    private EmployeeRepository employeeRepo;

    public Optional<AttendanceRecord> getLatestAttendanceRecord(Long employeeId) {
        Optional<Employee> emp = employeeRepo.findById(employeeId);
        if (emp.isEmpty()) return Optional.empty();

        return attendanceRepo.findLatestByEmployee(emp.get());
    }
}
